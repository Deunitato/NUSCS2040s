public class Edge{

    public Node source;
    public Node target;
    public int weight;

    public Edge(Node source, Node target, int weight) {
        this.source = source;
        this.target = target;
        this.weight = weight;
    }


}