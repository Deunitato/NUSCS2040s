/**
 * CS2040S Problem Set 3 - Speed Demon
 * 
 * Include the names of any collaborators here, and how they helped you.
 * Example: Tan Ah Kow - Discussed what Hash functions to use for the Problem
 * 
 */

public class MySpeedDemon {
    // Your code
    public static int speedMatch(String dbfilename) {
        // Your code
        return 0;
    }

    public static void main(String args[]) {
        if (args != null && args.length > 0) {
            int result = MySpeedDemon.speedMatch(args[0]);
            System.out.println(result);
        } else {
            throw new IllegalArgumentException();
        }
    }
}
